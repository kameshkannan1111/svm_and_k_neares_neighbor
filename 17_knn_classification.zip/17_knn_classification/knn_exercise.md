From sklearn.datasets load digits dataset and do following
 1. Classify digits (0 to 9) using KNN classifier. You can use different values for k neighbors and need to figure out a value of K that gives you a maximum score. You can manually try different values of K or use gridsearchcv 
 1. Plot confusion matrix
 1. Plot classification report

[Solution link](https://github.com/codebasics/py/blob/master/ML/17_knn_classification/Exercise/knn_exercise_digits_solution.ipynb)
